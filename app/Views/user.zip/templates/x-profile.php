
<div class="card">
  
  <!-- /.card-header -->
  <div class="card-body">
  </div>
  <div class="card-body">
    <!-- Main content -->
        <section class="content">
            <div class="container-fluid" style="align-items: center;">
                <h1 style="text-align: center"><?= strtoupper($kontakx[0]->nama_pt);?></h1>
                <hr>
                <br>
                <center><img  src="<?= base_url('uploads/files/').$data['logo']; ?>" alt="PT. Lancar Asia Industri" height="300" width="300"></center>
                <br>

                <h5 style="text-align: center">Dsn. Sidokerto RT/RW: 002/001</h5>
                <h5 style="text-align: center">Pulorejo Dawarblandong</h5>
                <h5 style="text-align: center">Mojokerto</h5>
              <hr>

            <!-- /.row (main row) -->
            </div><!-- /.container-fluid -->
        </section>

  </div>
  <!-- /.card-body -->
  <div class="card-body">
  </div>

</div>

<!-- jQuery -->
<script src="<?= base_url('assets/'); ?>plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?= base_url('assets/'); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
